# QMeS-Derivation
QMeS-derivation has been developed by

     Jan M. Pawlowski, Coralie Schneider and Nicolas Wink.

If used in scientific publications, please cite the corresponding paper,

    Jan M. Pawlowski, Coralie Schneider and Nicolas Wink.
    arXiv:2020.????? [hep-ph].

QMeS-derivation is maintained by selected members of the fQCD collaboration.
