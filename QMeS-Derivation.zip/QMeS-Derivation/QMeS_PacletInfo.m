(* ::Package:: *)

(* Paclet Info File *)

(* created 08/12/2020*)

Paclet[
    Name -> "QMeS",
    Version -> "1.0",
    MathematicaVersion -> "12+",
    Description -> "We present the Mathematica package QMeS-Derivation. It derives symbolic functional equations from a given master equation. The latter include functional renormalisation group equations, Dyson-Schwinger equations,  Slavnov-Taylor and Ward identities and their modifications in the presence of momentum cutoffs.  The modules allow to derive the functional equations, take functional derivatives, trace over field space, apply a given truncation scheme, and do  momentum routings while keeping track of prefactors and signs that arise from fermionic commutation relations. The package furthermore contains an installer as well as \textit{Mathematica} notebooks with showcase examples.",
    Creator -> "Jan M. Pawlowski, Coralie S. Schneider, Nicolas Wink",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "?"}
        }
]


