Fixed the notation of the classical action, see updated draft arXiv:2102.01410 [hep-ph].
