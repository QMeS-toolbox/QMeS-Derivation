# QMeS---Derivation
Derivation of symbolic functional equations starting from a master equation
