## Version 1.2
 - Renaming of the main file, package can be loaded now simply with ``<<"QMeSderivation`"``
 - Empty `"bosonic"->{}` or `"fermionic"->{}` can be omitted now when specifying fields
 - Internal reshuffeling, all subpackages are no inlucded in the main .m file
 - Updated installer to `PacletDataRebuild`

## Version 1.1
 - Fixed the notation of the classical action, see updated draft arXiv:2102.01410 [hep-ph].
